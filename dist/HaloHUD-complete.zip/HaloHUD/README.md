# HaloHUD for Assetto Corsa

**Version 1.10.0 · Assetto Corsa + CSP · MIT**

An unofficial, F1-inspired onboard telemetry overlay for Assetto Corsa. It draws a curved teal-and-navy HUD around the cockpit view using a CSP Lua app and original artwork.

![HaloHUD showing live-style telemetry](previews/HaloHUD-detail.png)

## Features

- Live speed in km/h and mph, gear, RPM, brake, throttle, battery charge, deploy and recovery gauges.
- A two-row timing panel with race-position tracking, a leader/second-place layout and a centered solo-player state.
- Animated Active Aero driven by DRS telemetry, plus configurable fallbacks for cars without KERS.
- Mouse positioning, live scale/curvature controls, independent panel sizes, themes and an optional outer arc.
- Automatic settings persistence and visibility that follows **Ctrl+H**.
- Synthetic demo telemetry, browser previews and reproducible texture generation with bundled OFL fonts.

## Getting started

### Requirements

To drive, use Windows, the original **Assetto Corsa**, **Content Manager** and **Custom Shaders Patch 0.2.0 or newer** (build 2651 minimum). Python, Node.js and system-installed fonts are not required to run the app.

The HUD targets a single screen. It uses screen-space projection: it has no true halo attachment, depth occlusion or camera parallax. Camera examples need car-specific calibration.

### Install or upgrade

Close Assetto Corsa before installing. When upgrading, back up your existing `apps/lua/HaloHUD/config.ini` and restore it afterward to keep your settings. Missing settings receive defaults.

#### Content Manager installation (recommended — easiest)

1. Download **HaloHUD-install.zip** from the release you want to install. Use the install ZIP, not HaloHUD-complete.zip, which includes development files.
2. Open Content Manager and select **Install from a file**.
3. Choose `HaloHUD-install.zip`, review the detected package and complete the installation.
4. Enable Lua apps in Content Manager if needed, start a session and open **HaloHUD controls** from the app sidebar.

If Content Manager does not recognize the package, use the manual method below.

#### Manual installation (alternative)

1. Extract `HaloHUD-install.zip`, or locate this project's [apps](apps/) folder.
2. Copy the `apps` folder into the Assetto Corsa installation root. The resulting path must be `assettocorsa/apps/lua/HaloHUD/manifest.ini`.
3. When upgrading, replace the Lua files **and** assets, then restore your saved `config.ini`.
4. Enable Lua apps in Content Manager if needed, start a session and open **HaloHUD controls** from the app sidebar.

Do not install `docs`, `source`, `tests` or previews into the game. The app does not edit car files.

### Position and configure the HUD

Enable **Drag HUD with mouse**, then left-drag the handle above the dial. Turn the option off when finished. Overall scale, X/Y offsets, curvature and independent panel scales also update immediately from the controls window.

Edits auto-save to [config.ini](apps/lua/HaloHUD/config.ini) after 0.4 seconds without changes. **Save config.ini** writes immediately; **Reset to defaults** restores and saves defaults; **Reload config.ini** reads external edits.

For example, edit these keys in the existing `[HUD]` section, then reload:

```ini
[HUD]
UNITS = MPH
THEME = ICE
SCALE = 0.90
OUTER_ARC = 1
```

Both speed units remain visible; `UNITS` selects the upper readout. See the [user guide](docs/USER-GUIDE.md) for all settings, gauge formulas and fallback behavior.

### Try demo mode

In a session, enable **Force demo telemetry** to animate the gauges without driving. Turn it off to restore automatic live/no-car selection. You can also open [the standalone browser demo](previews/Demo.html) directly; it needs no local web server.

## Development

### Set up the tools

Use **Python 3.10+** and **Node.js**. Node is used by the HTML/Lua animation parity test. Python dependencies are Pillow, Lupa and NumPy; their supported ranges are in [requirements.txt](source/requirements.txt).

Run these commands from the folder containing this README:

```powershell
python -m venv ../halohud-venv
..\halohud-venv\Scripts\python.exe -m pip install -r source/requirements.txt
..\halohud-venv\Scripts\python.exe -m unittest discover -s tests -v
```

The test harness executes Lua 5.1 through Lupa and mocks CSP interfaces. The current suite has 68 tests; it does not prove native mouse routing, engine integration or GPU performance.

### Generate assets, previews and packages

The virtual environment is kept outside the project so it is excluded from release packages. Using the same environment:

```powershell
..\halohud-venv\Scripts\python.exe source/build_assets.py
..\halohud-venv\Scripts\python.exe source/render_preview.py --html
..\halohud-venv\Scripts\python.exe source/render_states.py
..\halohud-venv\Scripts\python.exe source/render_aero_motion.py
..\halohud-venv\Scripts\python.exe source/verify_layout.py
..\halohud-venv\Scripts\python.exe source/build_package.py
```

Asset generation refreshes PNGs and glyph metadata. The package builder refreshes the source listing and SHA-256 inventory, verifies ZIP CRCs and asset dimensions, and writes install/complete ZIPs into `dist/` inside this project folder.

If you have CSP's generated SDK, verify declarations separately:

```powershell
..\halohud-venv\Scripts\python.exe tests/verify_sdk.py "C:/path/to/assettocorsa/extension/internal/lua-sdk/ac_apps/lib.lua"
```

### Publish a release

The [release workflow](.github/workflows/release.yml) runs when you push a version tag such as `v1.10.0`. The tag must match `VERSION` in the app manifest. Add a matching `### 1.10.0 — title` entry under this README’s **Changelog**, then commit your changes before tagging.

The workflow uses that entry’s body as the release description, runs the tests, builds both ZIPs and publishes them. Missing, empty or duplicate changelog entries fail the workflow instead of publishing incorrect notes. Ordinary branch pushes do not create releases. Assets are uploaded to a draft before publication, with retries for upload failures. An existing draft can be resumed; published releases are never overwritten automatically.

```powershell
git push origin main
git tag v1.10.0
git push origin v1.10.0
```

Use a new version/tag for each subsequent release.

If an upload fails, push any workflow fix to `main`, then open **Actions → Publish release → Run workflow**, select `main` and enter the existing tag. The workflow checks out that tag’s app files, uses the packaging tool from the workflow revision, and starts with a clean output folder before resuming its draft. Release assets have fixed names: HaloHUD-install.zip and HaloHUD-complete.zip. Rerunning an old failed run uses its old workflow definition. If the release is already published, inspect its assets and immutable status first; use a new version for a replacement when the existing release cannot be changed.

### Project layout

| Path | Purpose |
|---|---|
| [apps/lua/HaloHUD/](apps/lua/HaloHUD/) | Runtime Lua modules, manifest, configuration, generated textures and licenses. |
| [source/](source/) | Asset generators, renderers, inspection tools, package builder and source fonts. |
| [tests/](tests/) | Lua harness, regression tests and SDK declaration verifier. |
| [docs/](docs/) | Usage reference, API verification, car-profile notes and test checklist. |
| [previews/](previews/) | Rendered images, browser demos and approved visual references. |
| [camera/](camera/) | Separate example configurations; not installed automatically. |
| [reports/](reports/) | Recorded car/model inspections and highlight measurements. |

Start with `HaloHUD.lua` for CSP callbacks and controls, `telemetry.lua` for sampling and fallbacks, `settings.lua` for defaults/persistence, `renderer.lua` for layout and drawing, and `aero.lua` for animation. These modules live in `apps/lua/HaloHUD/`.

## Documentation and help

- [User guide](docs/USER-GUIDE.md): configuration, telemetry formulas, limitations and release history.
- [Testing checklist](docs/TESTING.md): offline commands and required in-game checks.
- [CSP API verification](docs/API-VERIFICATION.md): checked APIs and SDK baseline.
- [Formula Ultra 2026 profile](docs/CAR-PROFILE.md): verified sources, unknown values and exports needed for calibration.
- [Validation record](docs/VALIDATION.txt): completed checks and remaining in-game work.

For help, share a reproducible report with the person or repository that supplied your copy. Include the app/CSP versions, car ID, session type, resolution/UI scale, relevant config, expected/actual behavior and a screenshot or error text. No project support URL or named support contact is configured in this workspace.

The Formula Ultra profile uses available live powertrain data for the exact car ID. Packed physics, battery calibration and a working car-specific camera remain unverified. The 0.3 ms frame-time target also requires in-game measurement; it is not an offline guarantee.

## Changelog

Entries follow the development history. Dates are omitted where a release date was not recorded. The current app manifest is 1.10.0. Documentation and publishing changes are tracked separately.

### 1.10.0 — animated leaderboard

- Integrated the approved vertical leaderboard transition: player and opponent rows slide between their upper/lower positions, and solo sessions center the player.
- Attached the player highlight to the animated row using the panel’s shared projected strips and skew.
- Faded the opponent during row crossover to prevent overlapping names, and retained the previous opponent while fading into solo mode.
- Preserved motion through rapid reversals and renderer rebuilds, including resizing and HUD dragging.
- Added the auto-saved **Leaderboard animation** control (`LEADERBOARD_ANIMATION_MS`, default 450 ms, range 200–900 ms).
- Kept live race classification and existing gear/aero animations unchanged; expanded offline coverage to 64 tests.

### 1.9.0 — animated gear changes

- Added a smooth gear-selection highlight that slides right on upshifts and left on downshifts along the projected gear row.
- Preserved position and velocity during rapid shifts/reversals and layout rebuilds; nearby digit size and brightness blend with the sliding highlight.
- Added the approved N ↔ R pulse: 30% enlargement, letter swap at the peak, then a smooth return to normal size while the highlight stays in the first slot.
- Added the auto-saved **Gear animation** control (`GEAR_ANIMATION_MS`, default 260 ms, range 150–600 ms). The N/R pulse lasts twice this duration: 520 ms by default.
- Kept raw gear telemetry and saved layout settings unchanged; expanded offline coverage to 60 tests.

### 1.8.0 — curved gauges and battery contrast

- Integrated the approved HTML gauge layout into the Lua app: RECHARGE and DEPLOY now curve around and closely follow the speedometer rim.
- Kept blue energy fills continuous and bottom-up, with the existing telemetry formulas and damping. Tightened DEPLOY letter spacing.
- Gave brake/throttle gauges curved inner contours, fitted borders with small corners, and 16 equal-length segments. Their outer contours adjust to preserve segment length.
- Moved BRAKE and THROTTLE labels just below the gauges.
- Made depleted battery charge dark navy and remaining charge bright cyan for clearer visibility against gray liveries, retaining the battery shape and lightning icon without an outer border.
- Added reproducible curved-gauge texture generation and regression checks; retained live sizing, dragging, saved configuration and Ctrl+H behavior.

### 1.7.0 — mouse positioning

- Added **Drag HUD with mouse** and a small draggable handle above the dial.
- Connected mouse movement to the existing X/Y offsets and automatic config saving, using the actual fitted HUD scale.
- Kept movement within screen margins and retained immediate movement when reversing at an edge.
- Kept the fullscreen overlay click-through; Ctrl+H also hides the edit handle. Reset exits edit mode.
- Expanded the offline regression suite to 52 tests.

### 1.6.0 — brakes, battery and race-leader layout

- Changed brake bars to red.
- Restored a recognizable battery silhouette with a terminal nub, blue charge fill and lightning icon, without an outer border.
- In races, placed the player above second place when leading; retained the driver ahead above the player in other positions.
- Removed CLEAR TRACK from the race-leader layout and used UNAVAILABLE when opponent data is missing.

### 1.5.2 — reverse gear

- Replaced N with a highlighted R in the first gear slot while reversing; restored N in neutral and forward gears.

### 1.5.1 — global HUD visibility

- Made the overlay follow Ctrl+H and CSP global UI visibility without changing its saved enabled state.
- Kept telemetry updates and pending settings saves running while hidden.

### 1.5.0 — Active Aero animation

- Integrated the reviewed HTML animation into Lua: both slashes rotate clockwise into the active dashes and counterclockwise when deactivating, without crossing.
- Preserved smooth reversals and animation state through layout rebuilds.
- Added a configurable, automatically saved animation-duration slider.

### 1.4.1 — revised RPM threshold and inactive labels

- Changed the RPM bar's red threshold to strictly above **11,000 RPM**.
- Added separate grey boxes around inactive BOOST and OVERTAKE labels.
- Developed and reviewed the Active Aero HTML motion preview before its Lua integration.

### 1.4.0 — boost styling and automatic saving

- Removed TURN and changed OVERTAKE to plain styling.
- Highlighted BOOST in green when the displayed DEPLOY gauge exceeds 50%.
- Added automatic config saving after 0.4 seconds without edits, immediate Save, release-time flushing and failed-save retries.
- Initially used a 10,000 RPM red threshold, superseded by 1.4.1.

### 1.3.1 — AI race positions

- Used each car's live race position instead of leaderboard-array order in races, fixing the player incorrectly appearing first against bots.
- Selected the comparison driver by race position and handled missing ranks and opponents.

### 1.3.0 — readouts and solo sessions

- Removed leading zeros from both speed readouts.
- Increased brake and throttle columns to 16 segments.
- Changed the inactive Active Aero symbol to two side-by-side slashes.
- Centered the player row in solo sessions and removed its CLEAR TRACK row.

### 1.2.0 — panel geometry and car profile

- Matched the player-row highlight and text to the timing panel's curved projection and skew.
- Made RECHARGE and DEPLOY continuous blue fill gauges with damping, charging-rate calculation and configurable fallbacks.
- Removed the sponsor tag and rebalanced the right panel.
- Added the exact-ID Formula Ultra 2026 profile, inspection reports and separate camera guidance. Packed car data remained untouched; unavailable calibration values stayed unknown.

### 1.1.0 — live layout controls

- Added live overall scale, X/Y offsets, curvature and independent region scales, with Save and Reset controls.
- Added energy-gauge recovery calibration and fallback settings.
- Centered digit glyphs to correct spacing around 1, moved and reduced the DEMO label, and added the optional outer arc.

### 1.0.0 — initial overlay

- Established the curved teal-and-navy Lua HUD with timing, speed, gears, RPM, pedals, battery and aero indicators.
- Added synthetic demo telemetry, original generated artwork, installation instructions and offline validation tools.

## Maintainers and contributing

The license credits **HaloHUD contributors**. This workspace does not designate an individual maintainer or a public issue tracker.

Contributions to telemetry handling, layouts, verified car profiles, documentation and tests are welcome. Read [CONTRIBUTING.md](docs/CONTRIBUTING.md) before preparing a patch or pull request. Keep changes focused, verify CSP API names and include relevant offline/in-game evidence.

## License

Original code and artwork are covered by the [MIT license](LICENSE). Bundled fonts retain their separate [Orbitron OFL](source/fonts/Orbitron-OFL.txt) and [Barlow Condensed OFL](source/fonts/BarlowCondensed-OFL.txt) licenses.

## Affiliation

HaloHUD for Assetto Corsa is an independent fan project. It is not affiliated with, endorsed by, or sponsored by Formula 1, the Formula 1 companies, Kunos Simulazioni, or the Custom Shaders Patch developers. All trademarks belong to their respective owners.
